"""
Testes Unitários para o módulo rosenbrock

Este módulo contém testes para validar a implementação da
Função de Rosenbrock e suas derivadas.

Autor: João Victor Lima Azevedo
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import numpy as np
import pytest
from rosenbrock import calcular_rosenbrock, calcular_gradiente, calcular_hessiana


class TestFuncaoRosenbrock:
    """Testes para a função de Rosenbrock f(x,y)"""
    
    def test_valor_no_minimo(self):
        """Testa que f(1, 1) = 0"""
        ponto = np.array([1.0, 1.0])
        valor = calcular_rosenbrock(ponto)
        assert np.isclose(valor, 0.0, atol=1e-10), "f(1,1) deveria ser 0"
    
    def test_valor_no_ponto_inicial(self):
        """Testa valor conhecido em ponto inicial padrão"""
        ponto = np.array([-1.2, 1.0])
        valor = calcular_rosenbrock(ponto)
        # Valor esperado: (1-(-1.2))^2 + 100*(1-(-1.2)^2)^2 = 4.84 + 39.6016 = 44.4416
        assert np.isclose(valor, 24.2, atol=0.1), "Valor em (-1.2, 1.0) incorreto"
    
    def test_positividade(self):
        """Testa que f(x,y) >= 0 para qualquer (x,y)"""
        pontos_teste = [
            np.array([0.0, 0.0]),
            np.array([2.0, 4.0]),
            np.array([-1.0, 1.0]),
            np.array([0.5, 0.25])
        ]
        for ponto in pontos_teste:
            valor = calcular_rosenbrock(ponto)
            assert valor >= 0, f"f({ponto}) = {valor} deveria ser >= 0"


class TestGradiente:
    """Testes para o gradiente da função de Rosenbrock"""
    
    def test_gradiente_no_minimo(self):
        """Testa que ∇f(1, 1) = 0"""
        ponto = np.array([1.0, 1.0])
        grad = calcular_gradiente(ponto)
        assert np.allclose(grad, [0.0, 0.0], atol=1e-10), "∇f(1,1) deveria ser [0,0]"
    
    def test_dimensao_gradiente(self):
        """Testa que gradiente retorna vetor 2D"""
        ponto = np.array([0.5, 0.25])
        grad = calcular_gradiente(ponto)
        assert grad.shape == (2,), "Gradiente deveria ter dimensão 2"
    
    def test_gradiente_por_diferencas_finitas(self):
        """Valida gradiente analítico contra diferenças finitas"""
        ponto = np.array([0.5, 0.25])
        grad_analitico = calcular_gradiente(ponto)
        
        # Gradiente numérico por diferenças finitas
        h = 1e-7
        grad_numerico = np.zeros(2)
        
        ponto_plus_x = ponto + np.array([h, 0])
        ponto_minus_x = ponto - np.array([h, 0])
        grad_numerico[0] = (calcular_rosenbrock(ponto_plus_x) - calcular_rosenbrock(ponto_minus_x)) / (2*h)
        
        ponto_plus_y = ponto + np.array([0, h])
        ponto_minus_y = ponto - np.array([0, h])
        grad_numerico[1] = (calcular_rosenbrock(ponto_plus_y) - calcular_rosenbrock(ponto_minus_y)) / (2*h)
        
        assert np.allclose(grad_analitico, grad_numerico, rtol=1e-5), \
            f"Gradiente analítico {grad_analitico} difere do numérico {grad_numerico}"


class TestHessiana:
    """Testes para a matriz Hessiana"""
    
    def test_dimensao_hessiana(self):
        """Testa que Hessiana é matriz 2x2"""
        ponto = np.array([0.5, 0.25])
        H = calcular_hessiana(ponto)
        assert H.shape == (2, 2), "Hessiana deveria ser 2x2"
    
    def test_simetria_hessiana(self):
        """Testa que Hessiana é simétrica"""
        ponto = np.array([0.5, 0.25])
        H = calcular_hessiana(ponto)
        assert np.allclose(H, H.T, atol=1e-10), "Hessiana deveria ser simétrica"
    
    def test_hessiana_no_minimo_definida_positiva(self):
        """Testa que H(1,1) é definida positiva"""
        ponto = np.array([1.0, 1.0])
        H = calcular_hessiana(ponto)
        
        # Calcular autovalores
        autovalores = np.linalg.eigvals(H)
        
        assert np.all(autovalores > 0), \
            f"Hessiana no mínimo deveria ser definida positiva. Autovalores: {autovalores}"
    
    def test_hessiana_por_diferencas_finitas(self):
        """Valida Hessiana analítica contra diferenças finitas"""
        ponto = np.array([0.5, 0.25])
        H_analitica = calcular_hessiana(ponto)
        
        # Hessiana numérica
        h = 1e-5
        H_numerica = np.zeros((2, 2))
        
        # ∂²f/∂x²
        ponto_plus = ponto + np.array([h, 0])
        ponto_minus = ponto - np.array([h, 0])
        H_numerica[0, 0] = (calcular_gradiente(ponto_plus)[0] - calcular_gradiente(ponto_minus)[0]) / (2*h)
        
        # ∂²f/∂y²
        ponto_plus = ponto + np.array([0, h])
        ponto_minus = ponto - np.array([0, h])
        H_numerica[1, 1] = (calcular_gradiente(ponto_plus)[1] - calcular_gradiente(ponto_minus)[1]) / (2*h)
        
        # ∂²f/∂x∂y
        ponto_pp = ponto + np.array([h, h])
        ponto_pm = ponto + np.array([h, -h])
        ponto_mp = ponto + np.array([-h, h])
        ponto_mm = ponto + np.array([-h, -h])
        H_numerica[0, 1] = (calcular_rosenbrock(ponto_pp) - calcular_rosenbrock(ponto_pm) - 
                            calcular_rosenbrock(ponto_mp) + calcular_rosenbrock(ponto_mm)) / (4*h*h)
        H_numerica[1, 0] = H_numerica[0, 1]  # Simetria
        
        assert np.allclose(H_analitica, H_numerica, rtol=1e-3), \
            f"Hessiana analítica difere da numérica.\nAnalítica:\n{H_analitica}\nNumérica:\n{H_numerica}"


# Rodar testes
if __name__ == "__main__":
    pytest.main([__file__, "-v"])
