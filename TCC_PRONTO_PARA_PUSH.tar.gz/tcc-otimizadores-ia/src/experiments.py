"""
Módulo de Experimentos Computacionais

Este módulo executa os 4 experimentos planejados para comparar os algoritmos
de Gradiente Descendente e Newton-Raphson na função de Rosenbrock.

Autor: Trabalho de Conclusão de Curso
Data: 2025
"""

import numpy as np
import json
from optimizers import executar_gradiente_descendente, executar_newton_raphson


def experimento_1_convergencia_basica():
    """
    Experimento 1: Convergência Básica
    
    Objetivo: Comparar o comportamento padrão dos dois métodos usando
              configurações típicas da literatura.
    
    Configuração:
        - Ponto inicial: (-1.2, 1.0) [padrão da literatura]
        - GD: taxa de aprendizado α = 0.001
        - Tolerância: 1e-6
        - Máximo de iterações: 50000 (GD), 100 (NR)
    
    Returns:
        dict: Resultados do experimento contendo dados de ambos os métodos.
    """
    print("\n" + "="*70)
    print("EXPERIMENTO 1: CONVERGÊNCIA BÁSICA")
    print("="*70)
    
    ponto_inicial_padrao = np.array([-1.2, 1.0])
    tolerancia = 1e-6
    
    # Executar Gradiente Descendente
    print("\nExecutando Gradiente Descendente...")
    resultado_gd = executar_gradiente_descendente(
        ponto_inicial=ponto_inicial_padrao,
        taxa_aprendizado=0.001,
        iteracoes_maximas=50000,
        tolerancia_convergencia=tolerancia
    )
    
    print(f"  ✓ Iterações: {resultado_gd['iteracoes_totais']}")
    print(f"  ✓ Convergiu: {resultado_gd['convergiu']}")
    print(f"  ✓ Tempo: {resultado_gd['tempo_execucao']:.4f}s")
    print(f"  ✓ Ponto final: [{resultado_gd['ponto_final'][0]:.6f}, {resultado_gd['ponto_final'][1]:.6f}]")
    print(f"  ✓ Valor final: {resultado_gd['valor_final']:.2e}")
    
    # Executar Newton-Raphson
    print("\nExecutando Newton-Raphson...")
    resultado_nr = executar_newton_raphson(
        ponto_inicial=ponto_inicial_padrao,
        iteracoes_maximas=100,
        tolerancia_convergencia=tolerancia
    )
    
    print(f"  ✓ Iterações: {resultado_nr['iteracoes_totais']}")
    print(f"  ✓ Convergiu: {resultado_nr['convergiu']}")
    print(f"  ✓ Tempo: {resultado_nr['tempo_execucao']:.4f}s")
    print(f"  ✓ Ponto final: [{resultado_nr['ponto_final'][0]:.6f}, {resultado_nr['ponto_final'][1]:.6f}]")
    print(f"  ✓ Valor final: {resultado_nr['valor_final']:.2e}")
    
    # Comparação
    print("\n--- Comparação ---")
    razao_iteracoes = resultado_gd['iteracoes_totais'] / resultado_nr['iteracoes_totais']
    print(f"Razão de iterações (GD/NR): {razao_iteracoes:.1f}x")
    
    return {
        'gradiente_descendente': resultado_gd,
        'newton_raphson': resultado_nr,
        'configuracao': {
            'ponto_inicial': ponto_inicial_padrao.tolist(),
            'taxa_aprendizado_gd': 0.001,
            'tolerancia': tolerancia
        }
    }


def experimento_2_sensibilidade_learning_rate():
    """
    Experimento 2: Sensibilidade ao Learning Rate (apenas GD)
    
    Objetivo: Demonstrar a importância crítica do parâmetro α no Gradiente Descendente
              e mostrar que Newton-Raphson não sofre deste problema.
    
    Configuração:
        - Ponto inicial fixo: (-1.2, 1.0)
        - Testar α ∈ {0.0001, 0.0005, 0.001, 0.005, 0.01, 0.1}
        - Máximo de iterações: 50000
    
    Returns:
        dict: Resultados para cada valor de α testado.
    """
    print("\n" + "="*70)
    print("EXPERIMENTO 2: SENSIBILIDADE AO LEARNING RATE")
    print("="*70)
    
    ponto_inicial_padrao = np.array([-1.2, 1.0])
    valores_alpha = [0.0001, 0.0005, 0.001, 0.005, 0.01, 0.1]
    resultados = {}
    
    print("\nTestando diferentes valores de α:")
    print("-" * 70)
    
    for alpha in valores_alpha:
        print(f"\nα = {alpha}")
        
        resultado = executar_gradiente_descendente(
            ponto_inicial=ponto_inicial_padrao,
            taxa_aprendizado=alpha,
            iteracoes_maximas=50000,
            tolerancia_convergencia=1e-6
        )
        
        print(f"  Iterações: {resultado['iteracoes_totais']}")
        print(f"  Convergiu: {resultado['convergiu']}")
        print(f"  Tempo: {resultado['tempo_execucao']:.4f}s")
        print(f"  Valor final: {resultado['valor_final']:.2e}")
        
        resultados[f'alpha_{alpha}'] = resultado
    
    return {
        'resultados': resultados,
        'valores_alpha': valores_alpha,
        'ponto_inicial': ponto_inicial_padrao.tolist()
    }


def experimento_3_diferentes_pontos_iniciais():
    """
    Experimento 3: Robustez a Diferentes Pontos Iniciais
    
    Objetivo: Avaliar a consistência dos métodos quando iniciados de
              diferentes regiões do espaço de busca.
    
    Configuração:
        - Pontos iniciais: [(-1.2, 1.0), (0, 0), (2, 2), (-2, -1), (3, 7)]
        - GD: α = 0.001
        - Máximo de iterações: 50000 (GD), 100 (NR)
    
    Returns:
        dict: Resultados para cada ponto inicial testado.
    """
    print("\n" + "="*70)
    print("EXPERIMENTO 3: DIFERENTES PONTOS INICIAIS")
    print("="*70)
    
    pontos_iniciais = [
        np.array([-1.2, 1.0]),   # Padrão da literatura
        np.array([0.0, 0.0]),     # Origem
        np.array([2.0, 2.0]),     # Além do ótimo
        np.array([-2.0, -1.0]),   # Região negativa
        np.array([3.0, 7.0])      # Distante
    ]
    
    resultados_gd = []
    resultados_nr = []
    
    for idx, ponto in enumerate(pontos_iniciais):
        print(f"\n--- Ponto Inicial {idx + 1}: [{ponto[0]}, {ponto[1]}] ---")
        
        # Gradiente Descendente
        print("  GD:", end=" ")
        res_gd = executar_gradiente_descendente(
            ponto_inicial=ponto,
            taxa_aprendizado=0.001,
            iteracoes_maximas=50000,
            tolerancia_convergencia=1e-6
        )
        print(f"{res_gd['iteracoes_totais']} iter, {res_gd['tempo_execucao']:.4f}s")
        resultados_gd.append(res_gd)
        
        # Newton-Raphson
        print("  NR:", end=" ")
        res_nr = executar_newton_raphson(
            ponto_inicial=ponto,
            iteracoes_maximas=100,
            tolerancia_convergencia=1e-6
        )
        print(f"{res_nr['iteracoes_totais']} iter, {res_nr['tempo_execucao']:.4f}s")
        resultados_nr.append(res_nr)
    
    return {
        'pontos_iniciais': [p.tolist() for p in pontos_iniciais],
        'resultados_gd': resultados_gd,
        'resultados_nr': resultados_nr
    }


def experimento_4_custo_computacional():
    """
    Experimento 4: Trade-off entre Iterações e Tempo Computacional
    
    Objetivo: Analisar o custo computacional real, considerando que Newton-Raphson
              tem iterações mais caras (O(n³)) mas converge em menos passos.
    
    Configuração:
        - Mesma do Experimento 1
        - Análise detalhada de tempo por iteração
    
    Returns:
        dict: Análise detalhada do custo computacional.
    """
    print("\n" + "="*70)
    print("EXPERIMENTO 4: TRADE-OFF CUSTO COMPUTACIONAL")
    print("="*70)
    
    ponto_inicial_padrao = np.array([-1.2, 1.0])
    
    # Executar múltiplas vezes para média estatística
    num_repeticoes = 10
    print(f"\nExecutando {num_repeticoes} repetições para média estatística...")
    
    tempos_gd = []
    iteracoes_gd = []
    
    tempos_nr = []
    iteracoes_nr = []
    
    for i in range(num_repeticoes):
        # GD
        res_gd = executar_gradiente_descendente(
            ponto_inicial=ponto_inicial_padrao,
            taxa_aprendizado=0.001,
            iteracoes_maximas=50000,
            tolerancia_convergencia=1e-6
        )
        tempos_gd.append(res_gd['tempo_execucao'])
        iteracoes_gd.append(res_gd['iteracoes_totais'])
        
        # NR
        res_nr = executar_newton_raphson(
            ponto_inicial=ponto_inicial_padrao,
            iteracoes_maximas=100,
            tolerancia_convergencia=1e-6
        )
        tempos_nr.append(res_nr['tempo_execucao'])
        iteracoes_nr.append(res_nr['iteracoes_totais'])
    
    # Calcular médias
    tempo_medio_gd = np.mean(tempos_gd)
    tempo_medio_nr = np.mean(tempos_nr)
    
    iter_media_gd = np.mean(iteracoes_gd)
    iter_media_nr = np.mean(iteracoes_nr)
    
    # Tempo por iteração
    tempo_por_iter_gd = tempo_medio_gd / iter_media_gd
    tempo_por_iter_nr = tempo_medio_nr / iter_media_nr
    
    print("\n--- Resultados Médios ---")
    print(f"\nGradiente Descendente:")
    print(f"  Iterações médias: {iter_media_gd:.0f}")
    print(f"  Tempo total médio: {tempo_medio_gd:.4f}s")
    print(f"  Tempo por iteração: {tempo_por_iter_gd*1000:.4f}ms")
    
    print(f"\nNewton-Raphson:")
    print(f"  Iterações médias: {iter_media_nr:.0f}")
    print(f"  Tempo total médio: {tempo_medio_nr:.4f}s")
    print(f"  Tempo por iteração: {tempo_por_iter_nr*1000:.4f}ms")
    
    print(f"\n--- Comparações ---")
    print(f"Razão de iterações (GD/NR): {iter_media_gd/iter_media_nr:.1f}x")
    print(f"Razão de tempo por iteração (NR/GD): {tempo_por_iter_nr/tempo_por_iter_gd:.1f}x")
    print(f"Razão de tempo total (GD/NR): {tempo_medio_gd/tempo_medio_nr:.1f}x")
    
    return {
        'gradiente_descendente': {
            'iteracoes_media': float(iter_media_gd),
            'tempo_total_medio': float(tempo_medio_gd),
            'tempo_por_iteracao': float(tempo_por_iter_gd)
        },
        'newton_raphson': {
            'iteracoes_media': float(iter_media_nr),
            'tempo_total_medio': float(tempo_medio_nr),
            'tempo_por_iteracao': float(tempo_por_iter_nr)
        },
        'num_repeticoes': num_repeticoes
    }


def executar_todos_experimentos():
    """
    Executa todos os 4 experimentos e salva os resultados.
    
    Returns:
        dict: Dicionário contendo todos os resultados.
    """
    print("\n" + "="*70)
    print("EXECUÇÃO COMPLETA DOS EXPERIMENTOS DO TCC")
    print("="*70)
    
    resultados_completos = {}
    
    # Experimento 1
    resultados_completos['experimento_1'] = experimento_1_convergencia_basica()
    
    # Experimento 2
    resultados_completos['experimento_2'] = experimento_2_sensibilidade_learning_rate()
    
    # Experimento 3
    resultados_completos['experimento_3'] = experimento_3_diferentes_pontos_iniciais()
    
    # Experimento 4
    resultados_completos['experimento_4'] = experimento_4_custo_computacional()
    
    print("\n" + "="*70)
    print("TODOS OS EXPERIMENTOS CONCLUÍDOS COM SUCESSO!")
    print("="*70)
    
    return resultados_completos


def salvar_resultados(resultados, caminho_arquivo):
    """
    Salva os resultados dos experimentos em formato JSON.
    
    Args:
        resultados (dict): Dicionário com os resultados.
        caminho_arquivo (str): Caminho do arquivo de saída.
    """
    # Converter arrays numpy para listas para serialização JSON
    def converter_para_serializavel(obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, dict):
            return {k: converter_para_serializavel(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [converter_para_serializavel(item) for item in obj]
        else:
            return obj
    
    resultados_serializaveis = converter_para_serializavel(resultados)
    
    with open(caminho_arquivo, 'w', encoding='utf-8') as arquivo:
        json.dump(resultados_serializaveis, arquivo, indent=2, ensure_ascii=False)
    
    print(f"\n✓ Resultados salvos em: {caminho_arquivo}")


if __name__ == "__main__":
    # Executar todos os experimentos
    resultados = executar_todos_experimentos()
    
    # Salvar resultados
    caminho_saida = '/home/ubuntu/tcc_otimizacao/results/data/resultados_experimentos.json'
    salvar_resultados(resultados, caminho_saida)
