"""
Módulo de Implementação da Função de Rosenbrock

Este módulo contém a implementação da função de Rosenbrock e suas derivadas
(gradiente e matriz Hessiana), utilizadas como benchmark para comparação de
algoritmos de otimização.

Autor: Trabalho de Conclusão de Curso
Data: 2025
"""

import numpy as np


def calcular_rosenbrock(ponto):
    """
    Calcula o valor da função de Rosenbrock em um ponto dado.
    
    A função de Rosenbrock é definida como:
    f(x, y) = (1 - x)² + 100(y - x²)²
    
    Esta função é um benchmark clássico para testar algoritmos de otimização,
    caracterizada por um vale estreito e curvo que desafia métodos de primeira ordem.
    
    Args:
        ponto (np.ndarray): Vetor de coordenadas [x, y] onde avaliar a função.
    
    Returns:
        float: Valor da função de Rosenbrock no ponto fornecido.
    
    Examples:
        >>> calcular_rosenbrock(np.array([1.0, 1.0]))
        0.0
        >>> calcular_rosenbrock(np.array([0.0, 0.0]))
        1.0
    """
    coordenada_x = ponto[0]
    coordenada_y = ponto[1]
    
    # Primeiro termo: (1 - x)²
    termo_linear = (1.0 - coordenada_x) ** 2
    
    # Segundo termo: 100(y - x²)²
    termo_quadratico = 100.0 * (coordenada_y - coordenada_x ** 2) ** 2
    
    valor_superficie = termo_linear + termo_quadratico
    
    return valor_superficie


def calcular_gradiente(ponto):
    """
    Calcula o vetor gradiente da função de Rosenbrock em um ponto dado.
    
    O gradiente é a derivada de primeira ordem, definido como:
    ∇f = [∂f/∂x, ∂f/∂y]
    
    Onde:
    ∂f/∂x = -2(1-x) - 400x(y-x²)
    ∂f/∂y = 200(y-x²)
    
    Args:
        ponto (np.ndarray): Vetor de coordenadas [x, y] onde calcular o gradiente.
    
    Returns:
        np.ndarray: Vetor gradiente [∂f/∂x, ∂f/∂y] no ponto fornecido.
    
    Examples:
        >>> calcular_gradiente(np.array([1.0, 1.0]))
        array([0., 0.])
    """
    coordenada_x = ponto[0]
    coordenada_y = ponto[1]
    
    # Derivada parcial em relação a x: ∂f/∂x = -2(1-x) - 400x(y-x²)
    derivada_parcial_x = -2.0 * (1.0 - coordenada_x) - 400.0 * coordenada_x * (
        coordenada_y - coordenada_x ** 2
    )
    
    # Derivada parcial em relação a y: ∂f/∂y = 200(y-x²)
    derivada_parcial_y = 200.0 * (coordenada_y - coordenada_x ** 2)
    
    vetor_gradiente = np.array([derivada_parcial_x, derivada_parcial_y])
    
    return vetor_gradiente


def calcular_hessiana(ponto):
    """
    Calcula a matriz Hessiana da função de Rosenbrock em um ponto dado.
    
    A Hessiana é a matriz de derivadas de segunda ordem, definida como:
    H = [[∂²f/∂x²,    ∂²f/∂x∂y  ],
         [∂²f/∂y∂x,   ∂²f/∂y²   ]]
    
    Onde:
    ∂²f/∂x²   = -2 + 1200x² - 400y
    ∂²f/∂x∂y  = -400x
    ∂²f/∂y∂x  = -400x
    ∂²f/∂y²   = 200
    
    Args:
        ponto (np.ndarray): Vetor de coordenadas [x, y] onde calcular a Hessiana.
    
    Returns:
        np.ndarray: Matriz Hessiana 2x2 no ponto fornecido.
    
    Examples:
        >>> calcular_hessiana(np.array([1.0, 1.0]))
        array([[ 802., -400.],
               [-400.,  200.]])
    """
    coordenada_x = ponto[0]
    coordenada_y = ponto[1]
    
    # Elemento (1,1): ∂²f/∂x² = 2 + 1200x² - 400y
    elemento_11 = 2.0 + 1200.0 * coordenada_x ** 2 - 400.0 * coordenada_y
    
    # Elemento (1,2) e (2,1): ∂²f/∂x∂y = ∂²f/∂y∂x = -400x
    elemento_12 = -400.0 * coordenada_x
    elemento_21 = elemento_12  # Simetria da Hessiana
    
    # Elemento (2,2): ∂²f/∂y² = 200
    elemento_22 = 200.0
    
    matriz_hessiana = np.array([
        [elemento_11, elemento_12],
        [elemento_21, elemento_22]
    ])
    
    return matriz_hessiana


def validar_implementacao():
    """
    Valida a implementação das funções através de testes no mínimo global.
    
    O mínimo global da função de Rosenbrock está em (1, 1), onde:
    - f(1, 1) = 0
    - ∇f(1, 1) = [0, 0]
    - H(1, 1) deve ser positiva definida
    
    Returns:
        bool: True se todos os testes passarem, False caso contrário.
    """
    ponto_minimo = np.array([1.0, 1.0])
    
    # Teste 1: Valor da função no mínimo
    valor_minimo = calcular_rosenbrock(ponto_minimo)
    teste_valor = np.isclose(valor_minimo, 0.0, atol=1e-10)
    
    # Teste 2: Gradiente no mínimo deve ser zero
    gradiente_minimo = calcular_gradiente(ponto_minimo)
    teste_gradiente = np.allclose(gradiente_minimo, np.zeros(2), atol=1e-10)
    
    # Teste 3: Hessiana no mínimo deve ser positiva definida
    hessiana_minimo = calcular_hessiana(ponto_minimo)
    autovalores = np.linalg.eigvals(hessiana_minimo)
    teste_hessiana = np.all(autovalores > 0)
    
    print("=== Validação da Implementação ===")
    print(f"Valor no mínimo (1,1): {valor_minimo:.2e} (esperado: 0.0) - {'✓' if teste_valor else '✗'}")
    print(f"Gradiente no mínimo: {gradiente_minimo} (esperado: [0, 0]) - {'✓' if teste_gradiente else '✗'}")
    print(f"Autovalores da Hessiana: {autovalores} - {'✓' if teste_hessiana else '✗'}")
    print(f"Hessiana positiva definida: {teste_hessiana}")
    
    return teste_valor and teste_gradiente and teste_hessiana


if __name__ == "__main__":
    # Executar validação quando o módulo for rodado diretamente
    sucesso = validar_implementacao()
    
    if sucesso:
        print("\n✓ Todas as validações passaram com sucesso!")
    else:
        print("\n✗ Algumas validações falharam. Revisar implementação.")
