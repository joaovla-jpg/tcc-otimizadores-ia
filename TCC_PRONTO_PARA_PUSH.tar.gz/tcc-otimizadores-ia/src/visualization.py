"""
Módulo de Visualização de Resultados

Este módulo gera os gráficos profissionais para análise e apresentação
dos resultados dos experimentos de otimização.

Autor: Trabalho de Conclusão de Curso
Data: 2025
"""

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import json
from rosenbrock import calcular_rosenbrock
from optimizers import executar_gradiente_descendente, executar_newton_raphson


# Configuração global de estilo para gráficos profissionais
plt.rcParams['figure.figsize'] = (12, 8)
plt.rcParams['font.size'] = 11
plt.rcParams['axes.labelsize'] = 12
plt.rcParams['axes.titlesize'] = 14
plt.rcParams['legend.fontsize'] = 10
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10


def gerar_grafico_superficie_3d(resultado_gd, resultado_nr, caminho_saida):
    """
    Gráfico 1: Superfície 3D da Função de Rosenbrock com Trajetórias
    
    Mostra a superfície tridimensional da função com as trajetórias dos
    dois algoritmos sobrepostas, evidenciando visualmente a diferença de
    comportamento.
    
    Args:
        resultado_gd (dict): Resultados do Gradiente Descendente.
        resultado_nr (dict): Resultados do Newton-Raphson.
        caminho_saida (str): Caminho para salvar o gráfico.
    """
    fig = plt.figure(figsize=(14, 10))
    ax = fig.add_subplot(111, projection='3d')
    
    # Criar malha para a superfície
    intervalo_x = np.linspace(-2.5, 2.5, 100)
    intervalo_y = np.linspace(-1.0, 3.0, 100)
    malha_x, malha_y = np.meshgrid(intervalo_x, intervalo_y)
    
    # Calcular valores da função em cada ponto da malha
    malha_z = np.zeros_like(malha_x)
    for i in range(malha_x.shape[0]):
        for j in range(malha_x.shape[1]):
            ponto = np.array([malha_x[i, j], malha_y[i, j]])
            malha_z[i, j] = calcular_rosenbrock(ponto)
    
    # Aplicar escala logarítmica para melhor visualização
    malha_z_log = np.log10(malha_z + 1)
    
    # Plotar superfície
    superficie = ax.plot_surface(
        malha_x, malha_y, malha_z_log,
        cmap=cm.viridis,
        alpha=0.6,
        edgecolor='none',
        antialiased=True
    )
    
    # Extrair trajetórias
    trajetoria_gd = np.array(resultado_gd['historico_trajetoria'])
    trajetoria_nr = np.array(resultado_nr['historico_trajetoria'])
    
    valores_gd = np.array(resultado_gd['valores_convergencia'])
    valores_nr = np.array(resultado_nr['valores_convergencia'])
    
    # Aplicar escala logarítmica aos valores
    valores_gd_log = np.log10(valores_gd + 1)
    valores_nr_log = np.log10(valores_nr + 1)
    
    # Plotar trajetória do Gradiente Descendente (amostrar para não poluir)
    indices_amostra_gd = np.linspace(0, len(trajetoria_gd)-1, 200, dtype=int)
    ax.plot(
        trajetoria_gd[indices_amostra_gd, 0],
        trajetoria_gd[indices_amostra_gd, 1],
        valores_gd_log[indices_amostra_gd],
        'r-',
        linewidth=2.5,
        label='Gradiente Descendente',
        alpha=0.9
    )
    
    # Plotar trajetória do Newton-Raphson (todos os pontos)
    ax.plot(
        trajetoria_nr[:, 0],
        trajetoria_nr[:, 1],
        valores_nr_log,
        'b-o',
        linewidth=2.5,
        markersize=8,
        label='Newton-Raphson',
        alpha=0.9
    )
    
    # Marcar ponto inicial
    ponto_inicial = trajetoria_gd[0]
    valor_inicial_log = valores_gd_log[0]
    ax.scatter(
        ponto_inicial[0], ponto_inicial[1], valor_inicial_log,
        c='yellow',
        s=300,
        marker='*',
        edgecolors='black',
        linewidths=2,
        label='Ponto Inicial',
        zorder=10
    )
    
    # Marcar mínimo global
    ax.scatter(
        1.0, 1.0, 0.0,
        c='lime',
        s=300,
        marker='*',
        edgecolors='black',
        linewidths=2,
        label='Mínimo Global',
        zorder=10
    )
    
    # Configurações dos eixos
    ax.set_xlabel('x', fontsize=12, fontweight='bold')
    ax.set_ylabel('y', fontsize=12, fontweight='bold')
    ax.set_zlabel('log₁₀(f(x,y) + 1)', fontsize=12, fontweight='bold')
    ax.set_title(
        'Superfície da Função de Rosenbrock com Trajetórias de Otimização',
        fontsize=14,
        fontweight='bold',
        pad=20
    )
    
    # Legenda
    ax.legend(loc='upper left', framealpha=0.9)
    
    # Ângulo de visualização
    ax.view_init(elev=25, azim=45)
    
    # Colorbar
    fig.colorbar(superficie, ax=ax, shrink=0.5, aspect=5)
    
    plt.tight_layout()
    plt.savefig(caminho_saida, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"✓ Gráfico 1 (Superfície 3D) salvo em: {caminho_saida}")


def gerar_grafico_curvas_nivel(resultado_gd, resultado_nr, caminho_saida):
    """
    Gráfico 2: Curvas de Nível (Contour Plot)
    
    Vista superior da função mostrando as curvas de nível e as trajetórias,
    evidenciando o comportamento "zig-zag" do GD versus o caminho direto do NR.
    
    Args:
        resultado_gd (dict): Resultados do Gradiente Descendente.
        resultado_nr (dict): Resultados do Newton-Raphson.
        caminho_saida (str): Caminho para salvar o gráfico.
    """
    fig, ax = plt.subplots(figsize=(14, 10))
    
    # Criar malha para as curvas de nível
    intervalo_x = np.linspace(-2.0, 2.0, 300)
    intervalo_y = np.linspace(-1.0, 3.0, 300)
    malha_x, malha_y = np.meshgrid(intervalo_x, intervalo_y)
    
    # Calcular valores da função
    malha_z = np.zeros_like(malha_x)
    for i in range(malha_x.shape[0]):
        for j in range(malha_x.shape[1]):
            ponto = np.array([malha_x[i, j], malha_y[i, j]])
            malha_z[i, j] = calcular_rosenbrock(ponto)
    
    # Plotar curvas de nível com escala logarítmica
    niveis = np.logspace(-1, 3, 50)
    contorno = ax.contour(
        malha_x, malha_y, malha_z,
        levels=niveis,
        cmap='gray',
        alpha=0.4,
        linewidths=0.8
    )
    
    contorno_preenchido = ax.contourf(
        malha_x, malha_y, malha_z,
        levels=niveis,
        cmap='viridis',
        alpha=0.3
    )
    
    # Extrair trajetórias
    trajetoria_gd = np.array(resultado_gd['historico_trajetoria'])
    trajetoria_nr = np.array(resultado_nr['historico_trajetoria'])
    
    # Plotar trajetória do Gradiente Descendente (amostrar)
    indices_amostra_gd = np.linspace(0, len(trajetoria_gd)-1, 500, dtype=int)
    ax.plot(
        trajetoria_gd[indices_amostra_gd, 0],
        trajetoria_gd[indices_amostra_gd, 1],
        'r-',
        linewidth=2,
        label=f'Gradiente Descendente ({resultado_gd["iteracoes_totais"]} iter)',
        alpha=0.8
    )
    
    # Plotar trajetória do Newton-Raphson
    ax.plot(
        trajetoria_nr[:, 0],
        trajetoria_nr[:, 1],
        'b-o',
        linewidth=2.5,
        markersize=10,
        markerfacecolor='blue',
        markeredgecolor='white',
        markeredgewidth=1.5,
        label=f'Newton-Raphson ({resultado_nr["iteracoes_totais"]} iter)',
        alpha=0.9
    )
    
    # Marcar ponto inicial
    ax.scatter(
        trajetoria_gd[0, 0], trajetoria_gd[0, 1],
        c='yellow',
        s=400,
        marker='*',
        edgecolors='black',
        linewidths=2,
        label='Ponto Inicial',
        zorder=10
    )
    
    # Marcar mínimo global
    ax.scatter(
        1.0, 1.0,
        c='lime',
        s=400,
        marker='*',
        edgecolors='black',
        linewidths=2,
        label='Mínimo Global (1, 1)',
        zorder=10
    )
    
    # Configurações
    ax.set_xlabel('x', fontsize=13, fontweight='bold')
    ax.set_ylabel('y', fontsize=13, fontweight='bold')
    ax.set_title(
        'Curvas de Nível da Função de Rosenbrock\nComparação de Trajetórias',
        fontsize=15,
        fontweight='bold',
        pad=15
    )
    
    ax.legend(loc='upper right', framealpha=0.95, fontsize=11)
    ax.grid(True, alpha=0.3, linestyle='--')
    
    # Colorbar
    cbar = fig.colorbar(contorno_preenchido, ax=ax)
    cbar.set_label('f(x, y)', fontsize=12, fontweight='bold')
    
    plt.tight_layout()
    plt.savefig(caminho_saida, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"✓ Gráfico 2 (Curvas de Nível) salvo em: {caminho_saida}")


def gerar_grafico_convergencia(resultado_gd, resultado_nr, caminho_saida):
    """
    Gráfico 3: Convergência (Erro vs Iteração)
    
    O gráfico mais importante: mostra a taxa de convergência em escala logarítmica,
    comprovando convergência linear (GD) vs quadrática (NR).
    
    Args:
        resultado_gd (dict): Resultados do Gradiente Descendente.
        resultado_nr (dict): Resultados do Newton-Raphson.
        caminho_saida (str): Caminho para salvar o gráfico.
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))
    
    ponto_otimo = np.array([1.0, 1.0])
    
    # Calcular erros para GD
    trajetoria_gd = np.array(resultado_gd['historico_trajetoria'])
    erros_gd = [np.linalg.norm(ponto - ponto_otimo) for ponto in trajetoria_gd]
    
    # Calcular erros para NR
    trajetoria_nr = np.array(resultado_nr['historico_trajetoria'])
    erros_nr = [np.linalg.norm(ponto - ponto_otimo) for ponto in trajetoria_nr]
    
    # Gráfico 1: Erro em escala logarítmica
    ax1.semilogy(
        range(len(erros_gd)),
        erros_gd,
        'r-',
        linewidth=2,
        label='Gradiente Descendente',
        alpha=0.8
    )
    
    ax1.semilogy(
        range(len(erros_nr)),
        erros_nr,
        'b-o',
        linewidth=2.5,
        markersize=8,
        label='Newton-Raphson',
        alpha=0.9
    )
    
    ax1.set_xlabel('Iteração', fontsize=12, fontweight='bold')
    ax1.set_ylabel('||x - x*|| (escala log)', fontsize=12, fontweight='bold')
    ax1.set_title(
        'Taxa de Convergência: Erro vs Iteração',
        fontsize=13,
        fontweight='bold'
    )
    ax1.legend(fontsize=11)
    ax1.grid(True, alpha=0.3, which='both', linestyle='--')
    
    # Adicionar anotações
    ax1.annotate(
        'Convergência Linear\n(linha reta em log)',
        xy=(len(erros_gd)//2, erros_gd[len(erros_gd)//2]),
        xytext=(len(erros_gd)//2 + 5000, erros_gd[len(erros_gd)//2] * 10),
        arrowprops=dict(arrowstyle='->', color='red', lw=1.5),
        fontsize=10,
        color='red',
        fontweight='bold'
    )
    
    if len(erros_nr) > 3:
        ax1.annotate(
            'Convergência Quadrática\n(curva côncava)',
            xy=(len(erros_nr)-2, erros_nr[-2]),
            xytext=(len(erros_nr) + 10, erros_nr[-2] * 1000),
            arrowprops=dict(arrowstyle='->', color='blue', lw=1.5),
            fontsize=10,
            color='blue',
            fontweight='bold'
        )
    
    # Gráfico 2: Valor da função
    valores_gd = resultado_gd['valores_convergencia']
    valores_nr = resultado_nr['valores_convergencia']
    
    ax2.semilogy(
        range(len(valores_gd)),
        valores_gd,
        'r-',
        linewidth=2,
        label='Gradiente Descendente',
        alpha=0.8
    )
    
    ax2.semilogy(
        range(len(valores_nr)),
        valores_nr,
        'b-o',
        linewidth=2.5,
        markersize=8,
        label='Newton-Raphson',
        alpha=0.9
    )
    
    ax2.set_xlabel('Iteração', fontsize=12, fontweight='bold')
    ax2.set_ylabel('f(x, y) (escala log)', fontsize=12, fontweight='bold')
    ax2.set_title(
        'Evolução do Valor da Função',
        fontsize=13,
        fontweight='bold'
    )
    ax2.legend(fontsize=11)
    ax2.grid(True, alpha=0.3, which='both', linestyle='--')
    
    plt.tight_layout()
    plt.savefig(caminho_saida, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"✓ Gráfico 3 (Convergência) salvo em: {caminho_saida}")


def gerar_grafico_comparacao_desempenho(dados_exp1, dados_exp4, caminho_saida):
    """
    Gráfico 4: Comparação de Desempenho
    
    Gráfico de barras comparando métricas-chave: iterações, tempo e erro final.
    
    Args:
        dados_exp1 (dict): Dados do Experimento 1.
        dados_exp4 (dict): Dados do Experimento 4.
        caminho_saida (str): Caminho para salvar o gráfico.
    """
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    
    # Dados do Experimento 1
    gd = dados_exp1['gradiente_descendente']
    nr = dados_exp1['newton_raphson']
    
    # Dados do Experimento 4
    gd_exp4 = dados_exp4['gradiente_descendente']
    nr_exp4 = dados_exp4['newton_raphson']
    
    # Gráfico 1: Número de Iterações
    ax1 = axes[0, 0]
    metodos = ['Gradiente\nDescendente', 'Newton-\nRaphson']
    iteracoes = [gd['iteracoes_totais'], nr['iteracoes_totais']]
    cores = ['#e74c3c', '#3498db']
    
    barras = ax1.bar(metodos, iteracoes, color=cores, alpha=0.8, edgecolor='black', linewidth=1.5)
    ax1.set_ylabel('Número de Iterações', fontsize=11, fontweight='bold')
    ax1.set_title('Iterações até Convergência', fontsize=12, fontweight='bold')
    ax1.grid(axis='y', alpha=0.3, linestyle='--')
    
    # Adicionar valores nas barras
    for i, (barra, valor) in enumerate(zip(barras, iteracoes)):
        altura = barra.get_height()
        ax1.text(
            barra.get_x() + barra.get_width()/2,
            altura,
            f'{valor:,}',
            ha='center',
            va='bottom',
            fontweight='bold',
            fontsize=10
        )
    
    # Gráfico 2: Tempo Total
    ax2 = axes[0, 1]
    tempos = [gd_exp4['tempo_total_medio'] * 1000, nr_exp4['tempo_total_medio'] * 1000]  # em ms
    
    barras = ax2.bar(metodos, tempos, color=cores, alpha=0.8, edgecolor='black', linewidth=1.5)
    ax2.set_ylabel('Tempo Total (ms)', fontsize=11, fontweight='bold')
    ax2.set_title('Tempo de Execução Médio', fontsize=12, fontweight='bold')
    ax2.grid(axis='y', alpha=0.3, linestyle='--')
    
    for i, (barra, valor) in enumerate(zip(barras, tempos)):
        altura = barra.get_height()
        ax2.text(
            barra.get_x() + barra.get_width()/2,
            altura,
            f'{valor:.2f} ms',
            ha='center',
            va='bottom',
            fontweight='bold',
            fontsize=10
        )
    
    # Gráfico 3: Erro Final
    ax3 = axes[1, 0]
    ponto_otimo = np.array([1.0, 1.0])
    erro_gd = np.linalg.norm(gd['ponto_final'] - ponto_otimo)
    erro_nr = np.linalg.norm(nr['ponto_final'] - ponto_otimo)
    erros = [erro_gd, erro_nr]
    
    barras = ax3.bar(metodos, erros, color=cores, alpha=0.8, edgecolor='black', linewidth=1.5)
    ax3.set_ylabel('||x - x*||', fontsize=11, fontweight='bold')
    ax3.set_title('Erro Final (Distância ao Ótimo)', fontsize=12, fontweight='bold')
    ax3.set_yscale('log')
    ax3.grid(axis='y', alpha=0.3, linestyle='--', which='both')
    
    for i, (barra, valor) in enumerate(zip(barras, erros)):
        altura = barra.get_height()
        ax3.text(
            barra.get_x() + barra.get_width()/2,
            altura * 2,
            f'{valor:.2e}',
            ha='center',
            va='bottom',
            fontweight='bold',
            fontsize=9
        )
    
    # Gráfico 4: Tempo por Iteração
    ax4 = axes[1, 1]
    tempo_por_iter = [
        gd_exp4['tempo_por_iteracao'] * 1e6,  # em microsegundos
        nr_exp4['tempo_por_iteracao'] * 1e6
    ]
    
    barras = ax4.bar(metodos, tempo_por_iter, color=cores, alpha=0.8, edgecolor='black', linewidth=1.5)
    ax4.set_ylabel('Tempo por Iteração (μs)', fontsize=11, fontweight='bold')
    ax4.set_title('Custo Computacional por Iteração', fontsize=12, fontweight='bold')
    ax4.grid(axis='y', alpha=0.3, linestyle='--')
    
    for i, (barra, valor) in enumerate(zip(barras, tempo_por_iter)):
        altura = barra.get_height()
        ax4.text(
            barra.get_x() + barra.get_width()/2,
            altura,
            f'{valor:.2f} μs',
            ha='center',
            va='bottom',
            fontweight='bold',
            fontsize=10
        )
    
    plt.suptitle(
        'Comparação de Desempenho: Gradiente Descendente vs Newton-Raphson',
        fontsize=15,
        fontweight='bold',
        y=0.995
    )
    
    plt.tight_layout()
    plt.savefig(caminho_saida, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"✓ Gráfico 4 (Comparação de Desempenho) salvo em: {caminho_saida}")


def gerar_grafico_sensibilidade_alpha(dados_exp2, caminho_saida):
    """
    Gráfico 5: Sensibilidade ao Learning Rate
    
    Mostra como diferentes valores de α afetam a convergência do GD.
    
    Args:
        dados_exp2 (dict): Dados do Experimento 2.
        caminho_saida (str): Caminho para salvar o gráfico.
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))
    
    valores_alpha = dados_exp2['valores_alpha']
    resultados = dados_exp2['resultados']
    
    # Extrair métricas
    iteracoes = []
    valores_finais = []
    convergiu_lista = []
    
    for alpha in valores_alpha:
        chave = f'alpha_{alpha}'
        res = resultados[chave]
        iteracoes.append(res['iteracoes_totais'])
        valores_finais.append(res['valor_final'])
        convergiu_lista.append(res['convergiu'])
    
    # Gráfico 1: Iterações vs α
    cores = ['red' if not conv else 'green' for conv in convergiu_lista]
    
    ax1.plot(valores_alpha, iteracoes, 'o-', linewidth=2, markersize=10, color='navy')
    ax1.scatter(valores_alpha, iteracoes, c=cores, s=200, edgecolors='black', linewidths=2, zorder=5)
    
    ax1.set_xlabel('Taxa de Aprendizado (α)', fontsize=12, fontweight='bold')
    ax1.set_ylabel('Número de Iterações', fontsize=12, fontweight='bold')
    ax1.set_title('Sensibilidade ao Learning Rate', fontsize=13, fontweight='bold')
    ax1.set_xscale('log')
    ax1.grid(True, alpha=0.3, which='both', linestyle='--')
    
    # Adicionar legenda
    from matplotlib.patches import Patch
    legenda_elementos = [
        Patch(facecolor='green', edgecolor='black', label='Convergiu'),
        Patch(facecolor='red', edgecolor='black', label='Não Convergiu')
    ]
    ax1.legend(handles=legenda_elementos, fontsize=11)
    
    # Gráfico 2: Valor Final vs α
    ax2.semilogy(valores_alpha, valores_finais, 'o-', linewidth=2, markersize=10, color='purple')
    ax2.scatter(valores_alpha, valores_finais, c=cores, s=200, edgecolors='black', linewidths=2, zorder=5)
    
    ax2.set_xlabel('Taxa de Aprendizado (α)', fontsize=12, fontweight='bold')
    ax2.set_ylabel('Valor Final f(x, y) (escala log)', fontsize=12, fontweight='bold')
    ax2.set_title('Qualidade da Solução Final', fontsize=13, fontweight='bold')
    ax2.set_xscale('log')
    ax2.grid(True, alpha=0.3, which='both', linestyle='--')
    
    # Marcar α ótimo
    idx_otimo = convergiu_lista.index(True) if True in convergiu_lista else -1
    if idx_otimo >= 0:
        ax1.axvline(valores_alpha[idx_otimo], color='green', linestyle='--', linewidth=2, alpha=0.5)
        ax2.axvline(valores_alpha[idx_otimo], color='green', linestyle='--', linewidth=2, alpha=0.5)
        
        ax1.text(
            valores_alpha[idx_otimo],
            max(iteracoes) * 0.9,
            f'α ótimo = {valores_alpha[idx_otimo]}',
            fontsize=10,
            fontweight='bold',
            color='green',
            ha='center'
        )
    
    plt.tight_layout()
    plt.savefig(caminho_saida, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"✓ Gráfico 5 (Sensibilidade α) salvo em: {caminho_saida}")


def gerar_todas_visualizacoes():
    """
    Gera todos os gráficos do TCC.
    """
    print("\n" + "="*70)
    print("GERAÇÃO DE VISUALIZAÇÕES")
    print("="*70)
    
    # Carregar resultados dos experimentos
    with open('/home/ubuntu/tcc_otimizacao/results/data/resultados_experimentos.json', 'r') as f:
        dados = json.load(f)
    
    # Reexecutar Experimento 1 para obter objetos completos (não apenas dados serializados)
    print("\nRegenerando dados do Experimento 1 para visualizações...")
    ponto_inicial = np.array([-1.2, 1.0])
    
    resultado_gd = executar_gradiente_descendente(
        ponto_inicial=ponto_inicial,
        taxa_aprendizado=0.001,
        iteracoes_maximas=50000,
        tolerancia_convergencia=1e-6
    )
    
    resultado_nr = executar_newton_raphson(
        ponto_inicial=ponto_inicial,
        iteracoes_maximas=100,
        tolerancia_convergencia=1e-6
    )
    
    # Diretório de saída
    dir_plots = '/home/ubuntu/tcc_otimizacao/results/plots'
    
    # Gerar gráficos
    print("\nGerando gráficos...")
    
    gerar_grafico_superficie_3d(
        resultado_gd,
        resultado_nr,
        f'{dir_plots}/grafico_1_superficie_3d.png'
    )
    
    gerar_grafico_curvas_nivel(
        resultado_gd,
        resultado_nr,
        f'{dir_plots}/grafico_2_curvas_nivel.png'
    )
    
    gerar_grafico_convergencia(
        resultado_gd,
        resultado_nr,
        f'{dir_plots}/grafico_3_convergencia.png'
    )
    
    gerar_grafico_comparacao_desempenho(
        dados['experimento_1'],
        dados['experimento_4'],
        f'{dir_plots}/grafico_4_comparacao_desempenho.png'
    )
    
    gerar_grafico_sensibilidade_alpha(
        dados['experimento_2'],
        f'{dir_plots}/grafico_5_sensibilidade_alpha.png'
    )
    
    print("\n" + "="*70)
    print("TODAS AS VISUALIZAÇÕES FORAM GERADAS COM SUCESSO!")
    print("="*70)


if __name__ == "__main__":
    gerar_todas_visualizacoes()
