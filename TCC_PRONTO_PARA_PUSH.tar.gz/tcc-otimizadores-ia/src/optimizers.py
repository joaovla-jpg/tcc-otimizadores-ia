"""
Módulo de Algoritmos de Otimização

Este módulo implementa os métodos de Gradiente Descendente e Newton-Raphson
para otimização não-linear, aplicados à função de Rosenbrock.

Autor: Trabalho de Conclusão de Curso
Data: 2025
"""

import numpy as np
import time
from rosenbrock import calcular_rosenbrock, calcular_gradiente, calcular_hessiana


def executar_gradiente_descendente(
    ponto_inicial,
    taxa_aprendizado,
    iteracoes_maximas=10000,
    tolerancia_convergencia=1e-6
):
    """
    Executa o algoritmo de Gradiente Descendente para minimizar a função de Rosenbrock.
    
    O Gradiente Descendente é um método de primeira ordem que atualiza a posição
    movendo-se na direção oposta ao gradiente (descida mais íngreme):
    
    x_{k+1} = x_k - α · ∇f(x_k)
    
    onde α é a taxa de aprendizado (learning rate).
    
    Args:
        ponto_inicial (np.ndarray): Ponto de partida [x, y] para a otimização.
        taxa_aprendizado (float): Tamanho do passo (α) em cada iteração.
        iteracoes_maximas (int): Número máximo de iterações permitidas.
        tolerancia_convergencia (float): Critério de parada baseado na norma do gradiente.
    
    Returns:
        dict: Dicionário contendo:
            - 'historico_trajetoria': Lista de pontos visitados durante a otimização.
            - 'valores_convergencia': Lista de valores da função em cada ponto.
            - 'normas_gradiente': Lista das normas do gradiente em cada iteração.
            - 'iteracoes_totais': Número de iterações realizadas.
            - 'convergiu': Booleano indicando se o algoritmo convergiu.
            - 'tempo_execucao': Tempo total de execução em segundos.
            - 'ponto_final': Ponto final alcançado.
            - 'valor_final': Valor da função no ponto final.
    """
    # Inicialização
    ponto_atual = np.array(ponto_inicial, dtype=float)
    historico_trajetoria = [ponto_atual.copy()]
    valores_convergencia = [calcular_rosenbrock(ponto_atual)]
    normas_gradiente = []
    
    tempo_inicio = time.perf_counter()
    convergiu = False
    
    for iteracao in range(iteracoes_maximas):
        # Calcular o gradiente no ponto atual
        vetor_gradiente = calcular_gradiente(ponto_atual)
        norma_gradiente = np.linalg.norm(vetor_gradiente)
        normas_gradiente.append(norma_gradiente)
        
        # Verificar critério de convergência
        if norma_gradiente < tolerancia_convergencia:
            convergiu = True
            break
        
        # Atualizar posição: x_{k+1} = x_k - α · ∇f(x_k)
        direcao_descida = -vetor_gradiente
        ponto_atual = ponto_atual + taxa_aprendizado * direcao_descida
        
        # Registrar histórico
        historico_trajetoria.append(ponto_atual.copy())
        valor_atual = calcular_rosenbrock(ponto_atual)
        valores_convergencia.append(valor_atual)
        
        # Verificar divergência (valor explodindo)
        if valor_atual > 1e10:
            print(f"⚠ Divergência detectada na iteração {iteracao + 1}")
            break
    
    tempo_fim = time.perf_counter()
    tempo_execucao = tempo_fim - tempo_inicio
    
    iteracoes_totais = len(historico_trajetoria) - 1
    ponto_final = historico_trajetoria[-1]
    valor_final = valores_convergencia[-1]
    
    return {
        'historico_trajetoria': historico_trajetoria,
        'valores_convergencia': valores_convergencia,
        'normas_gradiente': normas_gradiente,
        'iteracoes_totais': iteracoes_totais,
        'convergiu': convergiu,
        'tempo_execucao': tempo_execucao,
        'ponto_final': ponto_final,
        'valor_final': valor_final
    }


def executar_newton_raphson(
    ponto_inicial,
    iteracoes_maximas=100,
    tolerancia_convergencia=1e-6,
    fator_regularizacao=1e-8
):
    """
    Executa o algoritmo de Newton-Raphson para minimizar a função de Rosenbrock.
    
    O método de Newton-Raphson é um algoritmo de segunda ordem que utiliza
    informação da curvatura (matriz Hessiana) para convergir quadraticamente:
    
    H_k · d_k = -∇f(x_k)
    x_{k+1} = x_k + d_k
    
    onde H_k é a Hessiana e d_k é a direção Newtoniana.
    
    Args:
        ponto_inicial (np.ndarray): Ponto de partida [x, y] para a otimização.
        iteracoes_maximas (int): Número máximo de iterações permitidas.
        tolerancia_convergencia (float): Critério de parada baseado na norma do gradiente.
        fator_regularizacao (float): Valor adicionado à diagonal da Hessiana para
                                     garantir definição positiva.
    
    Returns:
        dict: Dicionário contendo:
            - 'historico_trajetoria': Lista de pontos visitados durante a otimização.
            - 'valores_convergencia': Lista de valores da função em cada ponto.
            - 'normas_gradiente': Lista das normas do gradiente em cada iteração.
            - 'iteracoes_totais': Número de iterações realizadas.
            - 'convergiu': Booleano indicando se o algoritmo convergiu.
            - 'tempo_execucao': Tempo total de execução em segundos.
            - 'ponto_final': Ponto final alcançado.
            - 'valor_final': Valor da função no ponto final.
    """
    # Inicialização
    ponto_atual = np.array(ponto_inicial, dtype=float)
    historico_trajetoria = [ponto_atual.copy()]
    valores_convergencia = [calcular_rosenbrock(ponto_atual)]
    normas_gradiente = []
    
    tempo_inicio = time.perf_counter()
    convergiu = False
    
    for iteracao in range(iteracoes_maximas):
        # Calcular o gradiente no ponto atual
        vetor_gradiente = calcular_gradiente(ponto_atual)
        norma_gradiente = np.linalg.norm(vetor_gradiente)
        normas_gradiente.append(norma_gradiente)
        
        # Verificar critério de convergência
        if norma_gradiente < tolerancia_convergencia:
            convergiu = True
            break
        
        # Calcular a matriz Hessiana no ponto atual
        matriz_hessiana = calcular_hessiana(ponto_atual)
        
        # Regularização para garantir que a Hessiana seja positiva definida
        # H_regularizada = H + λI
        matriz_identidade = np.eye(2)
        hessiana_regularizada = matriz_hessiana + fator_regularizacao * matriz_identidade
        
        try:
            # Resolver o sistema linear: H · d = -∇f
            # Usamos solve ao invés de inverter a matriz (mais eficiente e estável)
            direcao_newtoniana = np.linalg.solve(
                hessiana_regularizada,
                -vetor_gradiente
            )
        except np.linalg.LinAlgError:
            print(f"⚠ Erro ao resolver sistema linear na iteração {iteracao + 1}")
            # Fallback: usar gradiente descendente com passo unitário
            direcao_newtoniana = -vetor_gradiente
        
        # Atualizar posição: x_{k+1} = x_k + d_k
        ponto_atual = ponto_atual + direcao_newtoniana
        
        # Registrar histórico
        historico_trajetoria.append(ponto_atual.copy())
        valor_atual = calcular_rosenbrock(ponto_atual)
        valores_convergencia.append(valor_atual)
    
    tempo_fim = time.perf_counter()
    tempo_execucao = tempo_fim - tempo_inicio
    
    iteracoes_totais = len(historico_trajetoria) - 1
    ponto_final = historico_trajetoria[-1]
    valor_final = valores_convergencia[-1]
    
    return {
        'historico_trajetoria': historico_trajetoria,
        'valores_convergencia': valores_convergencia,
        'normas_gradiente': normas_gradiente,
        'iteracoes_totais': iteracoes_totais,
        'convergiu': convergiu,
        'tempo_execucao': tempo_execucao,
        'ponto_final': ponto_final,
        'valor_final': valor_final
    }


def calcular_taxa_convergencia(historico_trajetoria, ponto_otimo, ordem=1):
    """
    Calcula a taxa de convergência empírica de um algoritmo.
    
    A taxa de convergência é definida como:
    r_k = ||x_{k+1} - x*|| / ||x_k - x*||^p
    
    onde p é a ordem de convergência (1 para linear, 2 para quadrática).
    
    Args:
        historico_trajetoria (list): Lista de pontos visitados.
        ponto_otimo (np.ndarray): Ponto ótimo conhecido.
        ordem (int): Ordem de convergência a testar (1 ou 2).
    
    Returns:
        np.ndarray: Array com as taxas de convergência em cada iteração.
    """
    taxas = []
    
    for indice in range(len(historico_trajetoria) - 1):
        ponto_atual = np.array(historico_trajetoria[indice])
        ponto_proximo = np.array(historico_trajetoria[indice + 1])
        
        erro_atual = np.linalg.norm(ponto_atual - ponto_otimo)
        erro_proximo = np.linalg.norm(ponto_proximo - ponto_otimo)
        
        # Evitar divisão por zero
        if erro_atual > 1e-15:
            taxa = erro_proximo / (erro_atual ** ordem)
            taxas.append(taxa)
        else:
            taxas.append(0.0)
    
    return np.array(taxas)


if __name__ == "__main__":
    print("=== Teste dos Algoritmos de Otimização ===\n")
    
    # Configuração do teste
    ponto_teste = np.array([-1.2, 1.0])
    ponto_otimo = np.array([1.0, 1.0])
    
    # Teste do Gradiente Descendente
    print("1. Gradiente Descendente:")
    resultado_gd = executar_gradiente_descendente(
        ponto_inicial=ponto_teste,
        taxa_aprendizado=0.001,
        iteracoes_maximas=10000
    )
    print(f"   Iterações: {resultado_gd['iteracoes_totais']}")
    print(f"   Convergiu: {resultado_gd['convergiu']}")
    print(f"   Tempo: {resultado_gd['tempo_execucao']:.4f}s")
    print(f"   Ponto final: {resultado_gd['ponto_final']}")
    print(f"   Valor final: {resultado_gd['valor_final']:.2e}\n")
    
    # Teste do Newton-Raphson
    print("2. Newton-Raphson:")
    resultado_nr = executar_newton_raphson(
        ponto_inicial=ponto_teste,
        iteracoes_maximas=100
    )
    print(f"   Iterações: {resultado_nr['iteracoes_totais']}")
    print(f"   Convergiu: {resultado_nr['convergiu']}")
    print(f"   Tempo: {resultado_nr['tempo_execucao']:.4f}s")
    print(f"   Ponto final: {resultado_nr['ponto_final']}")
    print(f"   Valor final: {resultado_nr['valor_final']:.2e}\n")
    
    print("✓ Testes concluídos!")
